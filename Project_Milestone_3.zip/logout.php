<?php

		session_start();
        session_destroy();
        setcookie("username","", time()-60);
        header( 'Location: login.php' ) ;

		
?>