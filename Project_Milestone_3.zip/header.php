		<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table border="1" class="table table-striped table-bordered table-hover table-success ">
		<tr>
		<thead><div class="jumbotron"><h1>School Addmission System</h1></thead>
		</tr>
		<tr >
		<th><a href="add.php" class="navbar-link">Add Student</a></th>
		<th><a href="detail.php" class="navbar-link">Student Detail</a></th>
		<th><a href="logout.php" class="navbar-link">Logout</a></th>
		
		</tr>
		</table>

</body>
</html>
