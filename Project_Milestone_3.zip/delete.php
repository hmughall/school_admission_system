<?php
include_once"db.php";
$flag=0;
	$delete_record = $_GET['del'];
	
	$query = "DELETE FROM student
			  WHERE student_id = '$delete_record'";
			   
	if(mysqli_query($connection,$query)){

		header("location:detail.php");
	}
?>