<?php
session_start();


if((!(isset($_COOKIE["username"]))) && (!(isset($_SESSION['user']))) ){

	header("Location: index.php");
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update Student</title>
</head>

<body>

<div class="container" align="center">

<?php include_once"db.php" ?>
<?php include"header.php"?>


<?php
$flag=2;
$u_id=$_GET['edit'];	


	if(isset($_POST['submit'])){
	
	$stu_name = $_POST["user_name"];
	$stu_father = $_POST["father_name"];
	$stu_school = $_POST["school_name"];
	$stu_roll = $_POST["roll_no"];
	$stu_class = $_POST["student_class"];
		
	$query = "update student set `student_name`='$stu_name', `father_name`='$stu_father', `student_school`='$stu_school', `student_roll`=$stu_roll, `class`='$stu_class' where student_id='$u_id'";
	
	$result = mysqli_query($connection, $query);
	$flag=1;
	
	
	if(!$result){
		 die("Database query failed:" . mysql_error());
		 $flag=0;
	}
	
	
}
?>
			
<?php			
if($flag==1){
?>
			<div class="alert alert-success" role="alert" style="margin-left:-20px;" >
                   
                    <span class="pull-left" style="font-size:13px; "><b>Data Updated Successfully !</b></span>
					<br>
            </div>
<?php
	}
$query="select * from student where student_id='$u_id'";
$result=mysqli_query($connection,$query);

 $row=mysqli_fetch_row($result);
	$stu_name = $row[1];
	$stu_father = $row[2];
	$stu_school = $row[3];
	$stu_roll = $row[4];
	$stu_class = $row[5];
	?>



<div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-6">
<form method="post" class="form-group" action="edit.php?edit=<?php echo $u_id;?>">
<h2 class="h2">Student's Registration Form</h2>
<br />
<table align="center" border="0">
<tr><td class="td">Student's Name</td>
<td class="td"><input type="text" value="<?php echo $stu_name;?>" name="user_name" required/></td>
</tr>
<tr><td class="td">Father's Name</td>
<td class="td">
<input type="text" name="father_name" value="<?php echo $stu_father;?>" required/></td>
</tr>
<tr><td class="td">
		School's Name</td><td class="td">
		<input type="text" name="school_name" value="<?php echo $stu_school;?>" required/></td></tr>
		<tr><td class="td">
	Roll No</td><td class="td">
		<input type="text" name="roll_no" value="<?php echo $stu_roll;?>" required/><br />
</td></tr><tr><td class="td">
Class</td><td class="td">
		<select name="student_class" required>
			<option value="-1">Select Class</option>
			<option value="10th"<?php if($stu_class=="10th"){?>selected="selected"<?php }?>>10th</option>
			<option value="9th" <?php if($stu_class=="9th"){?>selected="selected"<?php }?>>9th</option>
		</select></td>
		</tr>
		<tr><td class="td" colspan="2" align="right">
			<input type="submit" value="Send Data" name="submit" />
		</td></tr></table>
</form>
</div>

<div class="col-lg-3"></div>
</div>
</div>

</body>
</html>
