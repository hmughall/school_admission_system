<?php
session_start();


if((!(isset($_COOKIE["username"]))) && (!(isset($_SESSION['user']))) ){

	header("Location: index.php");
}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>View Students</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
</head>

<body><?php include_once"db.php"?>

<div class="container" align="center">
<?php include"header.php"?>
<div class="row">
<div class="col-lg-1"></div>
<div class="col-lg-10">
<table border="1"  class="table table-striped table-bordered table-hover table-primary ">
		<tr>
		<thead><h3 class="h3">Students Details</h3></thead>
		</tr>
		<tr >
		<th>Roll No.</th>
		<th>Student Name</th>
		<th>Father Name</th>
		<th>Class</th>
		<th>Privious School</th>
		<th>Edit</th>
		<th>Delete</th>
		</tr>
		
		
		<tr align="center">
	<?php
		$query = "SELECT * from student";
		
		$result = mysqli_query($connection, $query);
		while($row = mysqli_fetch_array($result)){
			$u_id = $row[0];
			$u_name = $row[1];
			$u_father = $row[2];
			$u_school=$row[3];
			$u_roll = $row[4];
			$u_class=$row[5];
	?>
		<td align="center"><?php echo $u_roll; ?></td>
		<td align="center"><?php echo $u_name; ?></td>
		<td align="center"><?php echo $u_father; ?></td>
		<td align="center"><?php echo $u_class; ?></td>
		<td align="center"><?php echo $u_school; ?></td>
		<td align="center"><a href="javascript:delete_id(<?php	echo $u_id;	?>)">Delete</a></td>
		<td align="center"><a href="edit.php?edit=<?php echo $u_id; ?>">Edit</a></td>
	</tr>
	<?php } ?>
		
		
		
		</table>
</div>
<div class="col-lg-1"></div>
</div></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

	function delete_id(id)
	{
	 if(confirm('Sure To Remove This Record ?'))
	 {
	  window.location.href='delete.php?del='+id;
	 }
	}

</script>

</body>
</html>
