<?php
session_start();


if((!(isset($_COOKIE["username"]))) && (!(isset($_SESSION['user']))) ){

	header("Location: index.php");
}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Add Student</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<style type="text/css">.td {padding:10px;}</style>
</head>

<body>
<div class="container" align="center">

<?php include_once"db.php" ?>
<?php include"header.php"?>


<?php
$flag=2;
	if(isset($_POST['submit'])){
	
	$stu_name = $_POST["user_name"];
	$stu_father = $_POST["father_name"];
	$stu_school = $_POST["school_name"];
	$stu_roll = $_POST["roll_no"];
	$stu_class = $_POST["student_class"];

	$query = "SELECT `student_roll` from student where `student_roll`='".$stu_roll."'";
		
		$result = mysqli_query($connection, $query);
		if(mysqli_num_rows($result)>0)
		{
?>
			
				<div class="alert alert-danger" role="alert" style="margin-left:-20px;" >
                   
                    <span class="pull-left" style="font-size:13px; "><b>This Roll Number already exists. Try Another</b></span>
					<br>
            </div>
<?php
		}else{



		
	$query = "INSERT INTO student(`student_name`, `father_name`, `student_school`, `student_roll`, `class`) VALUES('$stu_name', '$stu_father', '$stu_school', '$stu_roll', '$stu_class')";
	
	$result = mysqli_query($connection, $query);
	$flag=1;
	
	
	if(!$result){
		 die("Database query failed:" . mysqli_error($connection));
		 $flag=0;
	}
}
	
	
} 
?>
			
<?php			
if($flag==1){
?>
			<div class="alert alert-success" role="alert" style="margin-left:-20px;" >
                   
                    <span class="pull-left" style="font-size:13px; "><b>Data Inserted Successfully !</b></span>
					<br>
            </div>
<?php
	}?>



<div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-6">
<form method="post" class="form-group" action="add.php">
<h2 class="h2">Student's Registration Form</h2>
<br />
<table align="center" border="0">
<tr><td class="td">Student's Name</td>
<td class="td"><input type="text" name="user_name" required/></td>
</tr>
<tr><td class="td">Father's Name</td>
<td class="td">
<input type="text" name="father_name" required/></td>
</tr>
<tr><td class="td">
		School's Name</td><td class="td">
		<input type="text" name="school_name" required/></td></tr>
		<tr><td class="td">
	Roll No</td><td class="td">
		<input type="text" name="roll_no" required/><br />
</td></tr><tr><td class="td">
Class</td><td class="td">
		<select name="student_class" required>
			<option value="-1">Select Class</option>
			<option value="10th">10th</option>
			<option value="9th">9th</option>
		</select></td>
		</tr>
		<tr><td class="td" colspan="2" align="right">
			<input type="submit" value="Send Data" name="submit" />
		</td></tr></table>
</form>
</div>

<div class="col-lg-3"></div>
</div>
</div>

</body>
</html>
