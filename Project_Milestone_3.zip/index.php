<?php
session_start();


if((!(isset($_COOKIE["username"]))) && (!(isset($_SESSION['user']))) ){

	header("Location: login.php");
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<style type="text/css">.td {padding:10px;}</style>
</head>

<body>
<div class="container" align="center">
	<?php include"header.php"?>

<h3>Welcome <?php echo $_COOKIE['username']; ?></h3>
<p>You Are Logged In.</p>

</body>
</html>
