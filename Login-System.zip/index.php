<?php
session_start();
if(!$_SESSION['user']){

    header("location: login.php");

    

  }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>View Leaves</title>
 
</head>
<body>

	You Are Logged In To The System.
<br>
<br>
	<a href="logout.php"><button type="button" class="btn btn-primary">Logout</button></a>

</body>
</html>
