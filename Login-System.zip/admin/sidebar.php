<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
       
        <li>
			<a href="index.php">
			<i class="fa fa-book"></i> 
			<span>New Leaves</span>
			</a>
		</li>
		  <li>
			<a href="view_leaves.php">
			<i class="fa fa-book"></i> 
			<span>View Leaves</span>
			</a>
		</li>
		<li>
			<a href="new_accounts.php">
			<i class="fa fa-book"></i> 
			<span>New Accounts</span>
			</a>
		</li>
		<li>
			<a href="view_accounts.php">
			<i class="fa fa-book"></i> 
			<span>View Accounts</span>
			</a>
		</li>
		
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>