<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Developed By</b> Hamza Mughal
    </div>
    <strong>Copyright &copy; 2019  All rights
    reserved.
  </footer>